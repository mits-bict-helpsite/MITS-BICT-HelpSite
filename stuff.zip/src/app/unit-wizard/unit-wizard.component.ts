import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unit-wizard',
  templateUrl: './unit-wizard.component.html',
  styleUrls: ['./unit-wizard.component.css']
})
export class UnitWizardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
