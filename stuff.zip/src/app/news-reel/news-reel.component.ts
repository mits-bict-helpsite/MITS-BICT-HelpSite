import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news-reel',
  templateUrl: './news-reel.component.html',
  styleUrls: ['./news-reel.component.css']
})
export class NewsReelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
